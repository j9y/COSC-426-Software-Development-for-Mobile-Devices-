package com.example.passwordmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class InsertActivity extends AppCompatActivity {
    private DatabaseManager dbManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        dbManager = new DatabaseManager(this);
    }

    public void add(View v){
        EditText placeEditText = findViewById(R.id.inputPlace);
        String placeStr = placeEditText.getText().toString();

        EditText pwEditText = findViewById(R.id.inputPw);
        String pwStr = pwEditText.getText().toString();

        Model m = new Model(placeStr, pwStr);
        dbManager.insert(m);
    }

    public void back(View v){
        finish();
    }
}
