package com.example.passwordmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.LinkedList;

public class UpdateActivity extends AppCompatActivity {
    private DatabaseManager dbManager;

    private TextView[] places;
    private EditText [] pw;
    private Button[] buttons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        dbManager = new DatabaseManager(this);

        updateView();
    }

    public void updateView(){
        LinkedList<Model> list = dbManager.all();

        if(list.size()>0){
            Point size = new Point();
            getWindowManager().getDefaultDisplay().getSize(size);
            int screenWidth = size.x;
            int DP = (int)(getResources().getDisplayMetrics().density);

            int rows = list.size();
            int columns = 3;

            places = new TextView[rows];
            pw = new EditText[rows];
            buttons = new Button[rows];

            GridLayout grid = new GridLayout(this);
            grid.setRowCount(rows);
            grid.setColumnCount(columns);
            ScrollView.LayoutParams params = new ScrollView.LayoutParams(0,0);
            params.width = screenWidth;
            params.height = rows*(screenWidth/5);
            grid.setLayoutParams(params);

            for(int i=0; i<list.size(); i++){
                Model m = list.get(i);

                places[i] = new TextView(this);
                places[i].setText(m.getPlace());
                places[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                places[i].setTextColor(Color.parseColor("#000000"));
                places[i].setPadding(10*DP,10*DP,10*DP,10*DP);
                places[i].setGravity(Gravity.CENTER);
                GridLayout.LayoutParams params1 = new GridLayout.LayoutParams();
                params1.width = (int) (screenWidth *0.4);
                params1.height = screenWidth/5;
                params1.rowSpec = GridLayout.spec(0,1);
                places[i].setLayoutParams(params1);
                grid.addView(places[i]);

                pw[i] = new EditText(this);
                pw[i].setText(m.getPassword());
                pw[i].setTextSize(TypedValue.COMPLEX_UNIT_SP,20);
                pw[i].setTextColor(Color.parseColor("#000000"));
                pw[i].setPadding(10*DP,10*DP,10*DP,10*DP);
                pw[i].setGravity(Gravity.CENTER);
                params1 = new GridLayout.LayoutParams();
                params1.width = (int)(screenWidth*0.3);
                params1.height = screenWidth/5;
                params1.rowSpec = GridLayout.spec(i,0);
                params1.columnSpec = GridLayout.spec(1,1);
                pw[i].setLayoutParams(params1);
                grid.addView(pw[i]);

                buttons[i] = new Button(this);
                buttons[i].setText("SUBMIT");
                buttons[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                buttons[i].setTextColor(Color.parseColor("#000000"));
                buttons[i].setPadding(10*DP,10*DP,10*DP,10*DP);
                buttons[i].setGravity(Gravity.CENTER);
                params1 = new GridLayout.LayoutParams();
                params1.width = (int)(screenWidth*0.3);
                params1.height = screenWidth/5;
                params1.rowSpec = GridLayout.spec(i,1);
                params1.columnSpec = GridLayout.spec(2,1);
                buttons[i].setLayoutParams(params1);
                ButtonHandler temp = new ButtonHandler(i);
                buttons[i].setOnClickListener(temp);
                grid.addView(buttons[i]);
            }
            ScrollView scroll = findViewById(R.id.scroll);
            scroll.removeAllViewsInLayout();
            scroll.addView(grid);
        }
        else{
            ScrollView scroll = findViewById(R.id.scroll);
            scroll.removeAllViewsInLayout();
        }
    }

    private class ButtonHandler implements View.OnClickListener{
        private int rowNumber;

        public ButtonHandler(int rowNumber){
            this.rowNumber = rowNumber;
        }
        public void onClick(View view){
            String place = places[rowNumber].getText().toString();

            String password =pw[rowNumber].getText().toString();

            Model m = new Model(place, password);

            dbManager.update(m);
        }
    }

    public void back(View view){
        finish();
    }
}
