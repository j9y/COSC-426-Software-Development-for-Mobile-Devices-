package com.example.passwordmanager;

public class Model {
    private String place;
    private String password;

    public Model(String place, String password){
        this.place = place;
        this.password = password;
    }

    public String getPlace(){
        return place;
    }

    public String getPassword(){
        return password;
    }
}
