package com.example.encryption;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        updateView();
    }

    private void updateView(){
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        int key = preferences.getInt("PREFERENCE KEY",0);

        EditText keyInputEditText = findViewById(R.id.keyInput);
        keyInputEditText.setText(key+"");
    }
    public void submit(View v){
        EditText keyInputEditText = findViewById(R.id.keyInput);
        String keyInputStr = keyInputEditText.getText().toString();
        int key = Integer.parseInt(keyInputStr);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("PREFERENCE KEY",key);
        editor.apply();

        finish();
    }
}
