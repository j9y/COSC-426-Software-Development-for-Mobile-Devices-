package com.example.encryption;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void encrypt(View v){
        EditText editTextView = findViewById(R.id.input);
        String inputStr = editTextView.getText().toString();

        Model m = new Model();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        int key = preferences.getInt("PREFERENCE KEY",0);
        m.set(key);

        String output = m.encrypt(inputStr);

        editTextView.setText(output);
    }
    public void decrypt(View v){
        EditText editTextView = findViewById(R.id.input);
        String inputStr = editTextView.getText().toString();

        Model m = new Model();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        int key = preferences.getInt("PREFERENCE KEY",0);
        m.set(key);

        String output = m.decrypt(inputStr);
        editTextView.setText(output);

    }
    public void key(View v){
        Intent main2Activity = new Intent(this,Main2Activity.class);
        startActivity(main2Activity);
    }
}
