package com.example.emustadiumdirections;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void north(View v){
        Intent northActivity = new Intent(this, northActivity.class);
        startActivity(northActivity);
        overridePendingTransition(R.anim.north,R.anim.exitnorth);
    }
    public void south(View v){
        Intent southActivity = new Intent(this, southActivity.class);
        startActivity(southActivity);
        overridePendingTransition(R.anim.south, R.anim.exitsouth);
    }
    public void east(View v){
        Intent eastActivity = new Intent(this, eastActivity.class);
        startActivity(eastActivity);
        overridePendingTransition(R.anim.east, R.anim.exiteast);
    }
    public void west(View v){
        Intent westActivity = new Intent(this, westActivity.class);
        startActivity(westActivity);
        overridePendingTransition(R.anim.west, R.anim.exitwest);
    }
}
