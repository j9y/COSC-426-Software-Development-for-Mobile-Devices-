package com.example.emustadiumdirections;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class southActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_south);

        TextView textView = findViewById(R.id.southDirection);
        textView.setText("FROM SOUTH\n\n"+
                "Take US-23 North\n\n"+
                "Exit into Washtenaw East\n\n"+
                "Drive past Golfside\n\n"+
                "Turn left into Hewitt\n\n"+
                "Drive two blocks");
    }

    public void back(View v){
        finish();
        overridePendingTransition(R.anim.outgoing,0);
    }
}
