package com.example.emustadiumdirections;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class northActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_north);

        TextView textView = findViewById(R.id.northDirection);
        textView.setText("FROM NORTH\n\n"+
                "Take US-23 South\n\n"+
                "Exit into Washtenaw East\n\n"+
                "Drive past Carpenter\n\n"+
                "Turn left into Hewitt");
    }
    public void back(View v){
        finish();
        overridePendingTransition(R.anim.outgoing,0);
    }
}
