package com.example.emustadiumdirections;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class westActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_west);

        TextView textView = findViewById(R.id.westDirection);
        textView.setText("FROM WEST\n\n"+
                "Take I-96 East\n\n"+
                "Exit into Washtenaw East\n\n"+
                "Drive past Golfside\n\n"+
                "Turn left into Hewitt\n\n"+
                "Drive two blocks");
    }

    public void back(View v){
        finish();
        overridePendingTransition(R.anim.outgoing,0);
    }
}

