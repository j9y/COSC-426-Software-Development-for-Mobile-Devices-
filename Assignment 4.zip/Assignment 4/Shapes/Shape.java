package com.example.shapes;

public class Shape {
    private int x;
    private int y;
    private int radius;
    private int speed;
    private char direction;
    private String color;

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getRadius() {
        return radius;
    }

    public String getColor() {
        return color;
    }

    public Shape (int x, int y, int radius, int speed, char direction, String color){
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.speed = speed;
        this.direction = direction;
        this.color = color;
    }

    public void motion(){
        switch (direction){
            case 'N':
                y -= speed;
                if(y < 0 - radius*2)
                    y = 1000 + radius*2;
                break;
            case 'S':
                y += speed;
                if(y > 1000 + radius*2)
                    y = 0 - radius*2;
                break;
            case 'E':
                x += speed;
                if(x > 1800 + radius*2)
                    x = 0 - radius*2;
                break;
            case 'W':
                x -= speed;
                if(x < 0 - radius*2)
                    x = 1800 + radius*2;
                break;
        }
    }
}

