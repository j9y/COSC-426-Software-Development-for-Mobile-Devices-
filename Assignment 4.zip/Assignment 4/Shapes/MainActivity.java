package com.example.shapes;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.util.Timer;


public class MainActivity extends AppCompatActivity {
    private Game game;
    private GameView gameView;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        game = new Game();
        gameView = new GameView(this, game);

        setContentView(gameView);

        Timer timer = new Timer();
        GameTimerTask task = new GameTimerTask(game, gameView);
        timer.schedule(task, 0, 20);
    }
}