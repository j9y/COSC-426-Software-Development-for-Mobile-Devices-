package com.example.shapes;

import java.util.Random;

public class Game {
    private Shape[] circles;
    private Shape[] squares;
    private Random rd;

    public Game(){
        rd = new Random();
        circles = new Shape[10];
        squares = new Shape[10];

        for (int i = 0; i < circles.length; i++){
            int size = rd.nextInt(20) + 40;
            int x = rd.nextInt(1800);
            int y = rd.nextInt(1000);
            int delta = rd.nextInt(20) + 1;
            char direction = randomDirection();
            String color = randomColor();
            circles[i] = new Shape(x, y, size, delta, direction, color);
        }
        for (int i = 0; i < squares.length; i++){
            int size = rd.nextInt(20) + 40;
            int x = rd.nextInt(1800);
            int y = rd.nextInt(1000);
            int delta = rd.nextInt(20) + 1;
            char direction = randomDirection();
            String color = randomColor();
            squares[i] = new Shape(x, y, size, delta, direction, color);
        }
    }

    private String randomColor(){
        int directionValue = rd.nextInt(4);
        String color = "#000000";
        switch (directionValue){
            case 0:
                color = "#FF0000";
                break;
            case 1:
                color = "#00FF00";
                break;
            case 2:
                color = "#0000FF";
                break;
            case 3:
                color = "#FFFF00";
                break;
        }
        return color;
    }

    private char randomDirection(){
        int directionValue = rd.nextInt(4);
        char direction = 'N';
        switch (directionValue){
            case 0:
                direction = 'N';
                break;
            case 1:
                direction = 'S';
                break;
            case 2:
                direction = 'E';
                break;
            case 3:
                direction = 'W';
                break;
        }
        return direction;
    }

    public void move(){
        for (int i = 0; i < circles.length; i++)
            circles[i].motion();
        for (int i = 0; i < squares.length; i++)
            squares[i].motion();
    }

    public Shape[] getCircles() {
        return circles;
    }

    public Shape[] getSquares() {
        return squares;
    }
}