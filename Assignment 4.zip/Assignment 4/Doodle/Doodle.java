package com.example.doodle;

import java.util.ArrayList;

public class Doodle {
    private ArrayList<Point> listOfPoints;
    private String color;
    private int colorPointer;

    public Doodle(){
        listOfPoints = new ArrayList<>();
        color = "#000000";
        colorPointer = 0;
    }

    public void addPoint(int x, int y){
        listOfPoints.add(new Point(x, y, color));
    }

    public ArrayList<Point> getListOfPoints() {
        return listOfPoints;
    }

    public void changeColor(){
        colorPointer = colorPointer + 1;
        switch (colorPointer){
            case 0: color = "#000000"; break;
            case 1: color = "#FFFFFF"; break;
            case 2: color = "#808080"; break;
            case 3: color = "#FF0000"; break;
            case 4: color = "#00FF00"; break;
            case 5: color = "#0000FF"; break;
            case 6: color = "#FFFF00"; break;
            case 7: color = "#A52A2A"; break;
            default: color = "#000000"; colorPointer = 0; break;
        }
    }

    public String getColor() {
        return color;
    }
}

