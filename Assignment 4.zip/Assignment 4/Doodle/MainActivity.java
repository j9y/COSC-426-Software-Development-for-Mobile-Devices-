package com.example.doodle;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;

public class MainActivity extends AppCompatActivity {
    private Doodle doodle;
    private GraphicsView graphicsView;
    private GestureDetector gestureDetector;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        doodle = new Doodle();
        graphicsView = new GraphicsView(this, doodle);
        setContentView(graphicsView);

        TouchHandler temp =  new TouchHandler();
        gestureDetector = new GestureDetector(this, temp);
        gestureDetector.setOnDoubleTapListener(temp);
    }

    public boolean onTouchEvent(MotionEvent event){
        int x = (int)event.getRawX();
        int y = (int)event.getRawY() - 220;

        int action = event.getAction();

        if (x > 850 && x < 1000 && y > 1550 - 220 && y < 1700 -220){
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    doodle.changeColor();
                    break;
                case MotionEvent.ACTION_MOVE:
                    break;
            }
        } else {
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    doodle.addPoint(x, y);
                    break;
                case MotionEvent.ACTION_MOVE:
                    doodle.addPoint(x, y);
                    break;
            }
        }
        graphicsView.postInvalidate();
        return true;
    }

    private class TouchHandler extends GestureDetector.SimpleOnGestureListener{

    }
}