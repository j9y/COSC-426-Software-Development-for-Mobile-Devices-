package com.example.doodle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import java.util.ArrayList;

public class GraphicsView extends View {
    private Doodle doodle;
    private Paint paint;

    public GraphicsView(Context context, Doodle doodle){
        super(context);
        this.doodle = doodle;
        this.paint = new Paint();
    }

    public void onDraw(Canvas canvas){
        ArrayList<Point> listOfPoints = doodle.getListOfPoints();
        paint.setStyle(Paint.Style.FILL);

        for (int i = 0; i < listOfPoints.size(); i++){
            Point curr = listOfPoints.get(i);
            paint.setColor(Color.parseColor(curr.getColor()));
            canvas.drawCircle(curr.getX(), curr.getY(), 15, paint);
        }

        paint.setColor(Color.parseColor(doodle.getColor()));
        canvas.drawRect(850,1550 - 220,1000, 1700 -220, paint);
    }
}