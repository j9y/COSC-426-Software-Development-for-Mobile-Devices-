package com.example.slidingpuzzle;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.graphics.Point;
import android.view.GestureDetector;
import android.view.MotionEvent;

public class MainActivity extends AppCompatActivity {
    private static final int SIZE = 3;
    private Game game;
    private Board board;
    private boolean gameOver;
    private AppInterface appInterface;
    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Point screenSize = new Point();
        getWindowManager().getDefaultDisplay().getSize(screenSize);

        appInterface = new AppInterface(this, SIZE);

        initialize();
        setContentView(appInterface);
        TouchHandler temp = new TouchHandler();
        gestureDetector = new GestureDetector(this, temp);
        gameOver = false;
    }

    private void initialize(){
        game = new Game(SIZE);
        update();
    }

    private void update(){
        appInterface.updateBoard(game.getBoard());
    }

    public boolean onTouchEvent (MotionEvent event){
       if(!gameOver) gestureDetector.onTouchEvent(event);
        return true;
    }

    private class TouchHandler extends GestureDetector.SimpleOnGestureListener{
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            float startX = e1.getX(), startY = e1.getY();
            float endX = e2.getX(), endY = e2.getY();

            //Up and down
            if(Math.abs(startX - endX) < Math.abs(startY - endY)){
                //up
                if(startY > endY)
                    game.move("Up");
                    //down
                else
                    game.move("Down");
            }
            //Left and right
            else if (Math.abs(startX - endX) > Math.abs(startY - endY)){
                //right
                if(startX < endX)
                    game.move("Right");
                    //left
                else
                    game.move("Left");
            }
            appInterface.updateBoard(game.getBoard());

            if(game.solved()){
                board.stop();
                gameOver = true;
            }
            return super.onFling(e1, e2, velocityX, velocityY);
        }
    }

}
