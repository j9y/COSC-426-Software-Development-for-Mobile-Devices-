package com.example.shooting;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import java.util.Timer;

public class MainActivity extends AppCompatActivity {
    private Game game;
    private GameView gameView;
    private GestureDetector gestureDetector;

    private SoundPool soundPool;
    private int soundId;

    @SuppressLint("NewApi")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        game = new Game();

        gameView = new GameView(this, game);
        setContentView(gameView);

        GameTimerTask task = new GameTimerTask(game, gameView);
        Timer timer = new Timer();
        timer.schedule(task, 5000, 20 );

        TouchHandler temp = new TouchHandler();
        gestureDetector = new GestureDetector(this, temp);
        gestureDetector.setOnDoubleTapListener(temp);

        SoundPool.Builder soundPoolBuilder = new SoundPool.Builder();
        soundPool = soundPoolBuilder.build();
        //soundId = soundPool.load(this, R.raw.music, 1);
    }

    public boolean onTouchEvent (MotionEvent event){

        gestureDetector.onTouchEvent(event);

        return true;
    }

    private class TouchHandler extends GestureDetector.SimpleOnGestureListener{

        public boolean onDoubleTap(MotionEvent event){
            if(game.isHit()){
                soundPool.play(soundId,1,1,1,-1,1);
            }
            game.fire();

            return true;
        }

    }
}