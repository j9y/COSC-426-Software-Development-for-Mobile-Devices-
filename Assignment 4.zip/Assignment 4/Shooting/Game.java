package com.example.shooting;

public class Game {
    private double birdX;
    private double birdY;
    private double birdSpeed;

    private double bulletX;
    private double bulletY;
    private double bulletSpeed;
    private double bulletAngle;

    private double gunX;
    private double gunY;

    private double radius;
    private double distanceThreshold;

    private boolean fired;
    private boolean hit;

    public Game(){
        initializeGame();
    }

    public void update(){
        moveBird();

        if (fired)
            moveBullet();

        if (sceneClear())
            initializeGame();
    }

    public void fire(){
        fired = true;
    }


    public double getBirdX() {
        return birdX;
    }

    public double getBirdY() {
        return birdY;
    }

    public double getBulletX() {
        return bulletX;
    }

    public double getBulletY() {
        return bulletY;
    }

    public double getGunX() {
        return gunX;
    }

    public double getGunY() {
        return gunY;
    }

    public double getRadius() {
        return radius;
    }

    private void moveBird(){
        if (!hit){
            birdY = birdY - birdSpeed;
            hit = decideHit();
        }
        else
            birdY = birdY - birdSpeed;
    }

    private void moveBullet(){
        bulletX = bulletX + bulletSpeed*Math.cos(bulletAngle*Math.PI/180);
        bulletY = bulletY + bulletSpeed*Math.sin(bulletAngle*Math.PI/180);
    }

    private boolean decideHit(){
        double distance = Math.sqrt(Math.pow(birdX - bulletX, 2)
                + Math.pow(birdY - bulletY, 2));
        return distance <= distanceThreshold;
    }

    private boolean sceneClear(){
        return (birdX < 0 || birdY < 0 );
    }

    private void initializeGame(){
        double sceneWidth = 1400;
        double sceneHeight = 1000;
        double gunLength = 200;
        double gunAngle =  30 * Math.random();


        this.birdX = sceneWidth - 800 * Math.random();
        this.birdY = sceneHeight - radius;
        this.birdSpeed = 10 + 10 * Math.random();

        this.gunX = gunLength * Math.cos(gunAngle*Math.PI/180);
        this.gunY = gunLength * Math.sin(gunAngle*Math.PI/180);


        this.bulletX = gunX;
        this.bulletY = gunY;
        this.bulletSpeed = 20;
        this.bulletAngle = gunAngle;

        this.distanceThreshold = 100;
        this.radius = 50;

        this.fired = false;
        this.hit = false;
    }

    public boolean isHit() {
        return hit;
    }



}