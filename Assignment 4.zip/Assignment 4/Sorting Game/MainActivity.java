package com.example.sortinggame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Game game;
    private boolean playing;
    private AppInterface view;
    private GestureDetector gestureDetector;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        playing = true;
        game = new Game();
        view = new AppInterface(this);

        TouchHandler temp = new TouchHandler();
        gestureDetector = new GestureDetector(this, temp);
        gestureDetector.setOnDoubleTapListener(temp);

        view.update(game.getBoard(), game.getPointer(), game.getSwaps());
        setContentView(view);
    }

    public boolean onTouchEvent(MotionEvent event){
        gestureDetector.onTouchEvent(event);
        return true;
    }

    private void toast(String message){
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private class TouchHandler extends GestureDetector.SimpleOnGestureListener{
        @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {
            if (playing){
                game.movePointer();
                view.update(game.getBoard(), game.getPointer(), game.getSwaps());
            }
            return true;
        }

        @Override
        public boolean onDoubleTap(MotionEvent e) {
            if (playing){
                int next = game.swap();
                view.update(game.getBoard(), game.getPointer(), game.getSwaps());

                switch (next){
                    case 1:
                        toast("YOU WIN!");
                        playing = false;
                        break;
                    case -1:
                        toast("YOU LOSE!");
                        playing = false;
                        break;
                }
            }
            return true;
        }
    }
}