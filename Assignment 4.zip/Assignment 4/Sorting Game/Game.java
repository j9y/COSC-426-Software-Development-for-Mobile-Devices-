package com.example.sortinggame;

import java.util.Arrays;
import java.util.Random;

public class Game {
    private int totalSwaps;
    private int pointer;
    private int[] board;
    private int[] goal;

    public Game(){
        Random rd = new Random();
        totalSwaps = 45;
        pointer = 0;
        board = new int[10];
        goal = new int[board.length];

        for(int i = 0; i < board.length; i++)
            board[i] = rd.nextInt(100)+1;
        goal = board.clone();
        Arrays.sort(goal);
    }

    public int swap(){
        int temp = board[pointer];
        board[pointer] = board[pointer + 1];
        board[pointer + 1] = temp;
        totalSwaps --;

        if(isSorted()) {
            return 1;
        }
        else if (totalSwaps <= 0) {
            return -1;
        }
        else
            return 0;
    }

    public void movePointer(){
        if(pointer >= board.length - 2) {
            pointer = 0;
        }
        else
            pointer ++;
    }

    private boolean isSorted(){
        for(int i = 0; i < board.length; i++) {
            if (board[i] != goal[i]) {
                return false;
            }
        }
        return true;
    }


    public int getSwaps() {
        return totalSwaps;
    }

    public int[] getBoard() {
        return board;
    }

    public int getPointer() {
        return pointer;
    }

}