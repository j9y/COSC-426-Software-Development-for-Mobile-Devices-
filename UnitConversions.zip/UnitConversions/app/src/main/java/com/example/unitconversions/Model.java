package com.example.unitconversions;

public class Model {

    public float kmTomile(float kilometer){
        float mile = (float) (kilometer*0.62137);
        return mile;
    }

    public float mileToKm(float mile){
        float km = (float) (mile/0.62137);
        return km;
    }

    public float cmToInch(float centimeter){
        float ans = (float) (centimeter/2.54);
        return ans;
    }

    public float inchToCm(float inch){
        float ans = (float) (inch*2.54);
        return ans;
    }

    public float meterToFeet(float meter){
        float ans = (float) (meter*3.2808);
        return ans;
    }

    public float feetToMeter(float feet){
        float ans = (float) (feet/3.2808);
        return ans;
    }
}
