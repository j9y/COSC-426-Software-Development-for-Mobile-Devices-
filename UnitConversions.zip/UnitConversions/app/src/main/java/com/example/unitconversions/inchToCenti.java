package com.example.unitconversions;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class inchToCenti extends AppCompatActivity {
    Model m = new Model();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inch_to_centi);

        final EditText inchEditText = findViewById(R.id.inchInput);
        final EditText centiEditText = findViewById(R.id.centiInput);

        inchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String inchStr = inchEditText.getText().toString();
                float inch = Float.parseFloat(inchStr);
                TextView centiTextView = findViewById(R.id.centiOutput);
                centiTextView.setText(m.inchToCm(inch)+"");

            }
        });
        centiEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String centiStr = centiEditText.getText().toString();
                float cm = Float.parseFloat(centiStr);
                TextView inchOutputTextView = findViewById(R.id.inchOutput);
                inchOutputTextView.setText(m.cmToInch(cm)+"");

            }
        });

    }

    public void back(View view){
        finish();
    }
}
