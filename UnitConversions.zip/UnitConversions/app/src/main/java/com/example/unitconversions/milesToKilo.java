package com.example.unitconversions;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class milesToKilo extends AppCompatActivity {
    Model m = new Model();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_miles_to_kilo);

        final EditText mileEditText = findViewById(R.id.mileInput);
        final EditText kmEditText = findViewById(R.id.kiloInput);

        mileEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String mileStr = mileEditText.getText().toString();
                float mile = Float.parseFloat(mileStr);
                TextView kiloOutTextView = findViewById(R.id.kiloOutput);
                kiloOutTextView.setText(m.mileToKm(mile)+"");

            }
        });
        kmEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String kmStr = kmEditText.getText().toString();
                float km = Float.parseFloat(kmStr);
                TextView mileOutTextView = findViewById(R.id.mileOutput);
                mileOutTextView.setText(m.kmTomile(km)+"");

            }
        });

    }

    public void back(View view){
        finish();
    }
}
