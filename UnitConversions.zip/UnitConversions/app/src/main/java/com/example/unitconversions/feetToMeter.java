package com.example.unitconversions;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class feetToMeter extends AppCompatActivity {
    Model m = new Model();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feet_to_meter);

        final EditText feetEditText = findViewById(R.id.feetInput);
        final EditText meterEditText = findViewById(R.id.meterInput);

        feetEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String feetStr = feetEditText.getText().toString();
                float feet = Float.parseFloat(feetStr);
                TextView meterTextView = findViewById(R.id.meterOutput);
                meterTextView.setText(m.feetToMeter(feet)+"");

            }
        });
        meterEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String meterStr = meterEditText.getText().toString();
                float meter = Float.parseFloat(meterStr);
                TextView feetOutputTextView = findViewById(R.id.feetOutput);
                feetOutputTextView.setText(m.meterToFeet(meter)+"");

            }
        });

    }

    public void back(View view){
        finish();
    }
}

