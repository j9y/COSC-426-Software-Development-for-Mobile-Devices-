package com.example.retirementcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        updateView();

    }
    private void updateView(){
        Intent intent = getIntent();
        int principal = intent.getIntExtra("principal",0);
        int addition = intent.getIntExtra("addition",0);
        int years = intent.getIntExtra("years",0);
        int rate = intent.getIntExtra("rate",0);


        int a = (1+(Model.m.getRate()/100));

        TextView totalTextView = (TextView)findViewById(R.id.output);

        for(int i = 1; i <= Model.m.getYears(); i++){
            int total = Model.m.getTotal(i);
            totalTextView.append("\n\n"+i+"                                      "+total);
        }
    }

    public void back(View v){
        finish();
    }

}
