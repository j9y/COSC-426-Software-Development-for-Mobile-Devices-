package com.example.retirementcalculator;

public class Model {
    int principal;
    int addition;
    int years;
    int rate;
    public static Model m = new Model();



    public Model(){
        principal = 0;
        addition = 0;
        years = 0;
        rate = 0;
    }


    public void setPrincipal(int principal) {
        this.principal = principal;
    }

    public void setAddition(int addition) {
        this.addition = addition;
    }

    public void setYears(int years) {
        this.years = years;
    }

    public int getYears(){
        return years;
    }
    public int getPrincipal() {
        return principal;
    }

    public int getAddition() {
        return addition;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public static int power(final int base, final int power) {
        int result = 1;
        for( int i = 0; i < power; i++ ) {
            result *= base;
        }
        return result;
    }
    public int getTotal(int years){
        int a = (1+(rate/100));
        return (principal+100*(addition/rate))*power(a,years)-(100*(addition/rate));
    }


}

