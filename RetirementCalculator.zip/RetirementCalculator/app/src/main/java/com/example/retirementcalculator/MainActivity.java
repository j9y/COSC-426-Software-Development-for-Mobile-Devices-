package com.example.retirementcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void compute(View v){
        EditText principalEditText = (EditText)findViewById(R.id.inputcp);
        EditText additionEditText = (EditText)findViewById(R.id.inputaa);
        EditText yearsEditText = (EditText)findViewById(R.id.inputnoy);
        EditText rateEditText = (EditText)findViewById(R.id.inputirr);

        String principalStr = principalEditText.getText().toString();
        String additionStr = additionEditText.getText().toString();
        String yearStr = yearsEditText.getText().toString();
        String rateStr = rateEditText.getText().toString();

        int principal = Integer.parseInt(principalStr);
        int addition = Integer.parseInt(additionStr);
        int years = Integer.parseInt(yearStr);
        int rate = Integer.parseInt(rateStr);

        Model.m.setPrincipal(principal);
        Model.m.setAddition(addition);
        Model.m.setYears(years);
        Model.m.setRate(rate);


        Intent main2Activity = new Intent(this,Main2Activity.class);
        main2Activity.putExtra("principal",principal);
        main2Activity.putExtra("addition",addition);
        main2Activity.putExtra("years",years);
        main2Activity.putExtra("rate",rate);
        startActivity(main2Activity);
    }
}


